# Ekran Analizör — 9 Parçalı Resim Hata Bulucu

## Ne Yapar?
Telefon ekranını arka planda sürekli tarar. 9 parçalı bir resim gördüğünde, 8 uyumlu parça içinden yabancı olan 1 parçayı Claude AI ile bulur ve ekranda gösterir.

## Kurulum

### Gereksinimler
- Flutter SDK (3.0+)
- Android Studio
- Android telefon (API 26+ / Android 8.0+)
- Anthropic API anahtarı

### APK Oluşturma

```bash
# Bağımlılıkları yükle
flutter pub get

# Debug APK
flutter build apk --debug

# Release APK (daha küçük)
flutter build apk --release --split-per-abi
```

APK dosyası şuraya çıkar:
`build/app/outputs/flutter-apk/app-release.apk`

## Kullanım

1. APK'yı telefona yükle
2. Uygulamayı aç → Sağ üst **⚙️** ikonuna bas
3. Anthropic API anahtarını gir (`sk-ant-...`)
4. **Taramayı Başlat** butonuna bas
5. Ekran yakalama iznini ver
6. 9 parçalı resmi aç — uygulama otomatik tespit eder!

## İzinler
- `FOREGROUND_SERVICE` — arka planda çalışma
- `SYSTEM_ALERT_WINDOW` — overlay gösterme
- Ekran yakalama — MediaProjection (kullanıcı onayı gerekli)

## Nasıl Çalışır?

```
Ekran → MediaProjection → Base64 JPEG → Claude Vision API → Sonuç
  ↑                                                            ↓
  └──────────────── Her 2 saniyede bir ────────────────────────┘
```

## API Anahtarı
https://console.anthropic.com adresinden ücretsiz alabilirsin.
