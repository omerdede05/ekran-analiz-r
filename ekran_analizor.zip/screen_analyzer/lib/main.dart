import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'claude_service.dart';

void main() {
  runApp(const ScreenAnalyzerApp());
}

class ScreenAnalyzerApp extends StatelessWidget {
  const ScreenAnalyzerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ekran Analizör',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6C63FF)),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const _methodChannel = MethodChannel('com.screenanalyzer/capture');
  static const _eventChannel = EventChannel('com.screenanalyzer/frames');

  bool _isScanning = false;
  bool _isAnalyzing = false;
  String _apiKey = '';
  AnalysisResult? _lastResult;
  int _frameCount = 0;
  String _status = 'Hazır';

  ClaudeService? _claude;

  @override
  void initState() {
    super.initState();
    _loadApiKey();
    _listenToFrames();
  }

  Future<void> _loadApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    final key = prefs.getString('api_key') ?? '';
    setState(() {
      _apiKey = key;
      if (key.isNotEmpty) _claude = ClaudeService(key);
    });
  }

  void _listenToFrames() {
    _eventChannel.receiveBroadcastStream().listen((dynamic data) async {
      if (!_isScanning || _isAnalyzing || _claude == null) return;

      final base64 = data as String;
      setState(() {
        _frameCount++;
        _isAnalyzing = true;
        _status = 'Analiz ediliyor... (#$_frameCount)';
      });

      final result = await _claude!.analyzeScreen(base64);

      setState(() {
        _isAnalyzing = false;
        if (result != null && result.puzzleFound) {
          _lastResult = result;
          _status = '✅ Hatalı parça bulundu!';
        } else {
          _status = 'Taranıyor... (#$_frameCount)';
        }
      });
    });
  }

  Future<void> _toggleScanning() async {
    if (_apiKey.isEmpty) {
      _showApiKeyDialog();
      return;
    }

    if (_isScanning) {
      await _methodChannel.invokeMethod('stopCapture');
      setState(() {
        _isScanning = false;
        _status = 'Durduruldu';
      });
    } else {
      await _methodChannel.invokeMethod('startCapture');
      setState(() {
        _isScanning = true;
        _lastResult = null;
        _frameCount = 0;
        _status = 'Taranıyor...';
      });
    }
  }

  void _showApiKeyDialog() {
    final controller = TextEditingController(text: _apiKey);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('API Anahtarı'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            hintText: 'sk-ant-...',
            labelText: 'Anthropic API Key',
          ),
          obscureText: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('İptal'),
          ),
          FilledButton(
            onPressed: () async {
              final key = controller.text.trim();
              final prefs = await SharedPreferences.getInstance();
              await prefs.setString('api_key', key);
              setState(() {
                _apiKey = key;
                _claude = ClaudeService(key);
              });
              Navigator.pop(ctx);
            },
            child: const Text('Kaydet'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F7),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Ekran Analizör',
                        style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700),
                      ),
                      Text(
                        '9 parçalı resimde hata bulucu',
                        style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                      ),
                    ],
                  ),
                  IconButton(
                    onPressed: _showApiKeyDialog,
                    icon: const Icon(Icons.settings_outlined),
                    tooltip: 'API Ayarları',
                  ),
                ],
              ),

              const SizedBox(height: 32),

              // Durum kartı
              _StatusCard(
                isScanning: _isScanning,
                isAnalyzing: _isAnalyzing,
                status: _status,
                frameCount: _frameCount,
              ),

              const SizedBox(height: 24),

              // Sonuç kartı
              if (_lastResult != null) ...[
                _ResultCard(result: _lastResult!),
                const SizedBox(height: 24),
              ],

              const Spacer(),

              // API key uyarısı
              if (_apiKey.isEmpty)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.amber[50],
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.amber.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.warning_amber, color: Colors.amber[700], size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Başlamak için API anahtarı gerekli. Sağ üstten ayarlayın.',
                          style: TextStyle(fontSize: 13, color: Colors.amber[900]),
                        ),
                      ),
                    ],
                  ),
                ),

              const SizedBox(height: 16),

              // Başlat/Durdur butonu
              SizedBox(
                width: double.infinity,
                height: 56,
                child: FilledButton.icon(
                  onPressed: _toggleScanning,
                  style: FilledButton.styleFrom(
                    backgroundColor: _isScanning
                        ? Colors.red[400]
                        : const Color(0xFF6C63FF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  icon: Icon(_isScanning ? Icons.stop_rounded : Icons.play_arrow_rounded),
                  label: Text(
                    _isScanning ? 'Taramayı Durdur' : 'Taramayı Başlat',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final bool isScanning;
  final bool isAnalyzing;
  final String status;
  final int frameCount;

  const _StatusCard({
    required this.isScanning,
    required this.isAnalyzing,
    required this.status,
    required this.frameCount,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: isScanning ? Colors.green[50] : Colors.grey[100],
              shape: BoxShape.circle,
            ),
            child: Icon(
              isScanning ? Icons.radar : Icons.pause_circle_outline,
              color: isScanning ? Colors.green[600] : Colors.grey[400],
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  status,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                ),
                if (frameCount > 0)
                  Text(
                    '$frameCount kare analiz edildi',
                    style: TextStyle(fontSize: 13, color: Colors.grey[500]),
                  ),
              ],
            ),
          ),
          if (isAnalyzing)
            const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
        ],
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  final AnalysisResult result;

  const _ResultCard({required this.result});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.red[50],
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.red.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.error_outline, color: Colors.red[700]),
              const SizedBox(width: 8),
              Text(
                'Hatalı Parça Bulundu!',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Colors.red[700],
                ),
              ),
            ],
          ),
          if (result.errorPieceNumber != null) ...[
            const SizedBox(height: 12),
            _InfoRow(label: 'Parça No', value: '${result.errorPieceNumber}. parça'),
          ],
          if (result.location != null) ...[
            const SizedBox(height: 6),
            _InfoRow(label: 'Konum', value: result.location!),
          ],
          if (result.description != null) ...[
            const SizedBox(height: 6),
            _InfoRow(label: 'Sebep', value: result.description!),
          ],
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;

  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 70,
          child: Text(
            label,
            style: TextStyle(fontSize: 13, color: Colors.red[400], fontWeight: FontWeight.w500),
          ),
        ),
        Expanded(
          child: Text(value, style: const TextStyle(fontSize: 13)),
        ),
      ],
    );
  }
}
