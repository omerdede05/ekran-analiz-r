import 'dart:convert';
import 'package:http/http.dart' as http;

class ClaudeService {
  final String apiKey;
  static const String _baseUrl = 'https://api.anthropic.com/v1/messages';

  ClaudeService(this.apiKey);

  Future<AnalysisResult?> analyzeScreen(String base64Image) async {
    try {
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: jsonEncode({
          'model': 'claude-sonnet-4-6',
          'max_tokens': 1000,
          'messages': [
            {
              'role': 'user',
              'content': [
                {
                  'type': 'image',
                  'source': {
                    'type': 'base64',
                    'media_type': 'image/jpeg',
                    'data': base64Image,
                  },
                },
                {
                  'type': 'text',
                  'text': '''Bu ekran görüntüsünde 9 parçalı bir resim var mı? 
Eğer varsa:
- 8 parça birbirine uyumlu/bağlantılı bir ana resmin parçaları
- 1 parça tamamen farklı/yabancı/alakasız

Lütfen şu formatta cevap ver:
BULUNDU: [EVET/HAYIR]
HATALI_PARÇA: [1-9 arası numara veya YOK]
KONUM: [ekranda nerede: sol üst, orta, sağ alt vb.]
AÇIKLAMA: [neden farklı olduğu]

Eğer 9 parçalı resim yoksa sadece BULUNDU: HAYIR yaz.''',
                },
              ],
            },
          ],
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final text = data['content'][0]['text'] as String;
        return _parseResult(text);
      }
    } catch (e) {
      print('Claude API hatası: $e');
    }
    return null;
  }

  AnalysisResult _parseResult(String text) {
    final found = text.contains('BULUNDU: EVET');
    final pieceMatch = RegExp(r'HATALI_PARÇA:\s*(\d+)').firstMatch(text);
    final locationMatch = RegExp(r'KONUM:\s*(.+)').firstMatch(text);
    final descMatch = RegExp(r'AÇIKLAMA:\s*(.+)').firstMatch(text);

    return AnalysisResult(
      puzzleFound: found,
      errorPieceNumber: pieceMatch != null ? int.tryParse(pieceMatch.group(1)!) : null,
      location: locationMatch?.group(1)?.trim(),
      description: descMatch?.group(1)?.trim() ?? text,
      rawText: text,
    );
  }
}

class AnalysisResult {
  final bool puzzleFound;
  final int? errorPieceNumber;
  final String? location;
  final String? description;
  final String rawText;

  AnalysisResult({
    required this.puzzleFound,
    this.errorPieceNumber,
    this.location,
    this.description,
    required this.rawText,
  });
}
